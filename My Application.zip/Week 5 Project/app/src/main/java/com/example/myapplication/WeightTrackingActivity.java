package com.example.myapplication;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.lang.ref.WeakReference;
import java.util.List;

public class WeightTrackingActivity extends AppCompatActivity implements WeightDialogFragment.OnWeightEnteredListener, SMSDialogFragment.OnSMSApprovedListener{

    private static final int MY_PERMISSIONS_REQUEST_SEND_SMS =0 ;
    private com.example.myapplication.WeightDatabase mWeightdb;
    private WeightAdapter mWeightAdapter;
    private RecyclerView mRecyclerView;
    private RecyclerView.LayoutManager layoutManager;
    private Weight mSelectedWeight;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.weight_activity);
        mRecyclerView = findViewById(R.id.weightRecyclerView);

        // Singleton
        mWeightdb = mWeightdb.getInstance(getApplicationContext());


        layoutManager = new LinearLayoutManager(this);
        mRecyclerView.setLayoutManager(layoutManager);
        mRecyclerView.setHasFixedSize(true);


        mWeightAdapter = new WeightAdapter(loadWeights(), new ClickListener() {
            @Override
            public void onPositionClicked(int position) {

            }
        });
        mRecyclerView.setAdapter(mWeightAdapter);

        EditText mTargetWeight = findViewById(R.id.editTargetWeight);
        if(mWeightdb.getWeight("TARGET")!=0){
            mTargetWeight.setText(
                    String.valueOf(mWeightdb.getWeight("TARGET"))
            );
        }

        Button mSaveTarget = findViewById(R.id.btnTargetSave);
        mSaveTarget.setOnClickListener(mButtonClickListener);
    }

    public void sendSMSMessage() {
        if (ActivityCompat.checkSelfPermission(this,
                Manifest.permission.SEND_SMS) ==
                PackageManager.PERMISSION_GRANTED) {
            SharedPreferences sharedPref = this.getPreferences(Context.MODE_PRIVATE);
            int phoneNo = sharedPref.getInt("PhoneNumber", 0);
            String message = "Congratulations you achieved your target weight!";
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(String.valueOf(phoneNo), null, message, null, null);
            Toast.makeText(this, "SMS SENT", Toast.LENGTH_SHORT).show();
        }
    }

    private void checkForSmsPermission() {
        if (ActivityCompat.checkSelfPermission(this,
                Manifest.permission.SEND_SMS) !=
                PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS},
                    MY_PERMISSIONS_REQUEST_SEND_SMS);
        }
    }

    private View.OnClickListener mButtonClickListener = new View.OnClickListener() {
        public void onClick(View v) {
            EditText mTargetWeight = findViewById(R.id.editTargetWeight);
            if (mTargetWeight.getText().length() > 0) {
                Weight targetWeight = new Weight("TARGET", Integer.parseInt(mTargetWeight.getText().toString()));
                if (mWeightdb.addWeight(targetWeight)) {
                } else {
                    mWeightdb.updateWeight(targetWeight, "TARGET");
                }
            }
            mTargetWeight.clearFocus();
            InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(mTargetWeight.getWindowToken(), 0);
        }
    };

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_layout, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.smsNotif:
                if (item.isChecked()){
                    item.setChecked(false);
                } else {
                    if(ActivityCompat.checkSelfPermission(this,
                            Manifest.permission.SEND_SMS) ==
                            PackageManager.PERMISSION_GRANTED) {
                        item.setChecked(true);
                        FragmentManager manager = getSupportFragmentManager();
                        SMSDialogFragment smsdialog = new SMSDialogFragment();
                        smsdialog.show(manager, "smsDialog");
                    } else {
                        checkForSmsPermission();
                    }

                }
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    public void onWeightEntered(String date, int weight) {
        // Returns weight entered in the WeightDialogFragment dialog
        if (weight > 0 && date.length() > 0) {
            Weight weightDate = new Weight(date, weight);
            if (mWeightdb.addWeight(weightDate)) {
                mWeightAdapter.addWeight(weightDate);
                Toast.makeText(this, "Added " + date, Toast.LENGTH_SHORT).show();
                if(weightDate.getWeight()==mWeightdb.getWeight("TARGET")){
                    sendSMSMessage();
                }
            } else {
                String message = getResources().getString(R.string.date_exists);
                Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public void onWeightEdited(String oldDate, String newDate, int weight) {
        if (weight > 0 && newDate.length() > 0) {
            Weight weightDate = new Weight(newDate, weight);
            if (mWeightdb.updateWeight(weightDate, oldDate)) {
                mWeightAdapter.setData(mWeightdb.getWeights());
                Toast.makeText(this, "Edited " + oldDate, Toast.LENGTH_SHORT).show();
            } else {
                String message = getResources().getString(R.string.date_conflict);
                Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
            }

        }
    }

    public void addWeightClick(View view) {
        // Prompt user to type new weight
        FragmentManager manager = getSupportFragmentManager();
        WeightDialogFragment dialog = new WeightDialogFragment();
        Bundle args = new Bundle();
        args.putBoolean("edit", false);
        dialog.setArguments(args);
        dialog.show(manager, "weightDialog");
    }

    public List<Weight> loadWeights() {
        return mWeightdb.getWeights();
    }

    public interface ClickListener {
        void onPositionClicked(int position);
    }

    public class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.WeightHolder> {
        private final ClickListener listener;
        private List<Weight> mWeightList;

        public class WeightHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
            private TextView vDate;
            private TextView vWeight;
            private WeakReference<ClickListener> listenerRef;
            private ImageButton delButton;
            private ImageButton editButton;

            public WeightHolder(View v, ClickListener listener) {
                super(v);
                vDate = v.findViewById(R.id.textDate);
                vWeight = v.findViewById(R.id.textWeight);

                listenerRef = new WeakReference<>(listener);
                editButton = v.findViewById(R.id.buttonWeightEdit);
                delButton = v.findViewById(R.id.buttonWeightDelete);

                v.setOnClickListener(this);
                editButton.setOnClickListener(this);
                delButton.setOnClickListener(this);
            }

            @Override
            public void onClick(View v) {
                mSelectedWeight = mWeightList.get(getAdapterPosition());

                if (v.getId() == editButton.getId()) {

                    FragmentManager manager = getSupportFragmentManager();
                    WeightDialogFragment dialog = new WeightDialogFragment();
                    Bundle args = new Bundle();
                    args.putString("date", mSelectedWeight.getDate());
                    args.putInt("weight", mSelectedWeight.getWeight());
                    args.putInt("position", getAdapterPosition());
                    args.putBoolean("edit", true);

                    dialog.setArguments(args);
                    dialog.show(manager, "weightDialog");

                } else if (v.getId() == delButton.getId()){
                    mWeightdb.deleteWeight(mSelectedWeight);
                    mWeightAdapter.removeWeight(mSelectedWeight);
                }
                listenerRef.get().onPositionClicked(getAdapterPosition());
            }
        }

        public void setData(List<Weight> data){
            this.mWeightList = data;
            notifyDataSetChanged();
        }

        public WeightAdapter(List<Weight> weights, ClickListener listener) {
            this.mWeightList = weights;
            this.listener = listener;
        }

        @Override
        public WeightHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.weight_tracking_recycler, parent, false);

            return new WeightHolder(itemView, listener);
        }

        @Override
        public void onBindViewHolder(WeightHolder holder, int position){
            Weight weight = mWeightList.get(position);
            holder.vDate.setText(weight.getDate());
            holder.vWeight.setText(weight.getWeight()+" lbs");
        }

        public void addWeight(Weight weight) {
            // Add the new weight at the beginning of the list
            mWeightList.add(0, weight);

            // Notify the adapter that item was added to the beginning of the list
            notifyItemInserted(0);

            // Scroll to the top
            mRecyclerView.scrollToPosition(0);
        }

        public void removeWeight(Weight weight) {
            // Find weight in the list
            int index = mWeightList.indexOf(weight);
            if (index >= 0) {
                // Remove the weight
                mWeightList.remove(index);

                // Notify adapter of weight removal
                notifyItemRemoved(index);
            }
        }

        @Override
        public int getItemCount() {
            return mWeightList.size();
        }
    }

}